package com.example.helloworldprework

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log //imported
import android.widget.Button //imported
import android.widget.TextView //imported

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.button).setOnClickListener { //When the user clicks on the button

            Log.i("Johnny","Tapped on button")

            findViewById<TextView>(R.id.textView).setTextColor(getResources().getColor(R.color.white))
        }
    }
}